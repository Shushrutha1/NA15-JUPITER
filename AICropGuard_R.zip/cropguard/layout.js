import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
    Camera, 
    Home, 
    History, 
    Settings, 
    Leaf, 
    Languages,
    Volume2,
    VolumeX,
    MessageCircle
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [language, setLanguage] = useState("english");
  const [voiceEnabled, setVoiceEnabled] = useState(true);

  const translations = {
    english: {
      appName: "CropGuard AI",
      tagline: "Smart Crop Protection",
      dashboard: "Dashboard",
      camera: "Scan Crop",
      chatbot: "AI Assistant",
      history: "History",
      settings: "Settings",
      language: "Language",
      voice: "Voice Assistant"
    },
    telugu: {
      appName: "క్రాప్‌గార్డ్ AI",
      tagline: "స్మార్ట్ పంట రక్షణ",
      dashboard: "డాష్‌బోర్డ్",
      camera: "పంట స్కాన్",
      chatbot: "AI అసిస్టెంట్",
      history: "చరిత్ర",
      settings: "సెట్టింగ్‌లు",
      language: "భాష",
      voice: "వాయిస్ అసిస్టెంట్"
    }
  };

  const t = translations[language];

  const navigationItems = [
    {
      title: t.dashboard,
      url: createPageUrl("Dashboard"),
      icon: Home,
    },
    {
      title: t.camera,
      url: createPageUrl("CameraCapture"),
      icon: Camera,
    },
    {
      title: t.chatbot,
      url: createPageUrl("Chatbot"),
      icon: MessageCircle,
    },
    {
      title: t.history,
      url: createPageUrl("History"),
      icon: History,
    },
    {
      title: t.settings,
      url: createPageUrl("Settings"),
      icon: Settings,
    },
  ];

  useEffect(() => {
    const savedLanguage = localStorage.getItem("cropguard-language");
    const savedVoice = localStorage.getItem("cropguard-voice");
    if (savedLanguage) setLanguage(savedLanguage);
    if (savedVoice) setVoiceEnabled(savedVoice === "true");
  }, []);

  const toggleLanguage = () => {
    const newLanguage = language === "english" ? "telugu" : "english";
    setLanguage(newLanguage);
    localStorage.setItem("cropguard-language", newLanguage);
  };

  const toggleVoice = () => {
    const newVoiceEnabled = !voiceEnabled;
    setVoiceEnabled(newVoiceEnabled);
    localStorage.setItem("cropguard-voice", newVoiceEnabled.toString());
  };

  return (
    <SidebarProvider>
      <style>
        {`
          :root {
            --primary-green: #1B5E20;
            --secondary-green: #4CAF50;
            --accent-orange: #FF8F00;
            --bg-cream: #FAFAFA;
            --text-dark: #212121;
            --success-green: #2E7D32;
            --warning-amber: #F57C00;
          }
          
          .gradient-bg {
            background: linear-gradient(135deg, #1B5E20 0%, #4CAF50 100%);
          }
          
          .glass-effect {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.9);
          }
          
          .farmer-card {
            border: 2px solid #E8F5E8;
            border-radius: 16px;
            transition: all 0.3s ease;
          }
          
          .farmer-card:hover {
            border-color: #4CAF50;
            box-shadow: 0 8px 24px rgba(76, 175, 80, 0.15);
            transform: translateY(-2px);
          }
        `}
      </style>
      
      <div className="min-h-screen flex w-full" style={{ backgroundColor: 'var(--bg-cream)' }}>
        <Sidebar className="border-r-2 border-green-100">
          <SidebarHeader className="gradient-bg p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Leaf className="w-7 h-7 text-white" />
              </div>
              <div className="text-white">
                <h2 className="text-xl font-bold">{t.appName}</h2>
                <p className="text-sm text-green-100">{t.tagline}</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-2">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`farmer-card p-4 text-base font-medium ${
                          location.pathname === item.url 
                            ? 'bg-green-50 text-green-800 border-green-300' 
                            : 'hover:bg-green-50 hover:text-green-700'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-4">
                          <item.icon className="w-6 h-6" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t-2 border-green-100 p-4">
            <div className="space-y-3">
              <Button
                variant="outline"
                onClick={toggleLanguage}
                className="w-full justify-start gap-3 farmer-card"
              >
                <Languages className="w-5 h-5" />
                <span>{t.language}</span>
                <Badge variant="secondary" className="ml-auto">
                  {language === "english" ? "EN" : "తె"}
                </Badge>
              </Button>
              
              <Button
                variant="outline"
                onClick={toggleVoice}
                className="w-full justify-start gap-3 farmer-card"
              >
                {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                <span>{t.voice}</span>
                <Badge 
                  variant={voiceEnabled ? "default" : "secondary"}
                  className="ml-auto"
                >
                  {voiceEnabled ? "ON" : "OFF"}
                </Badge>
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="glass-effect border-b-2 border-green-100 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-green-50 p-2 rounded-lg transition-colors duration-200" />
              <div className="flex items-center gap-2">
                <Leaf className="w-6 h-6 text-green-600" />
                <h1 className="text-xl font-bold text-green-800">{t.appName}</h1>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}