import React, { useState, useEffect, useRef } from "react";
import { ChatMessage } from "@/entities/ChatMessage";
import { CropAnalysis } from "@/entities/CropAnalysis";
import { InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
    ArrowLeft, 
    Send, 
    Mic, 
    MicOff, 
    MessageCircle, 
    Leaf,
    Cloud,
    TrendingUp,
    AlertCircle,
    Bot,
    User,
    Loader2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import VoiceInputButton from "../components/chatbot/VoiceInputButton";
import ChatMessageBubble from "../components/chatbot/ChatMessageBubble";
import QuickActionButtons from "../components/chatbot/QuickActionButtons";
import WeatherCard from "../components/chatbot/WeatherCard";
import OfflineTipsCard from "../components/chatbot/OfflineTipsCard";

const translations = {
    english: {
        title: "AgriBot Assistant",
        subtitle: "Your AI farming companion",
        typePlaceholder: "Ask about crops, diseases, fertilizers...",
        send: "Send",
        quickActions: "Quick Actions",
        diseaseHelp: "Disease Help",
        weatherInfo: "Weather Info",
        marketPrices: "Market Prices",
        fertilizers: "Fertilizers",
        irrigation: "Irrigation",
        pesticides: "Pesticides",
        offlineMode: "Offline Mode",
        welcomeMessage: "Hello! I'm your AgriBot assistant. I can help you with crop diseases, fertilizers, weather updates, and farming best practices. How can I assist you today?",
        voicePrompt: "Listening... Please speak now",
        noInternet: "No internet connection. Showing offline tips."
    },
    telugu: {
        title: "అగ్రిబోట్ అసిస్టెంట్",
        subtitle: "మీ AI వ్యవసాయ సహాయకుడు",
        typePlaceholder: "పంటలు, వ్యాధులు, ఎరువుల గురించి అడగండి...",
        send: "పంపండి",
        quickActions: "త్వరిత చర్యలు",
        diseaseHelp: "వ్యాధి సహాయం",
        weatherInfo: "వాతావరణ సమాచారం",
        marketPrices: "మార్కెట్ ధరలు",
        fertilizers: "ఎరువులు",
        irrigation: "నీటిపారుదల",
        pesticides: "పురుగుమందులు",
        offlineMode: "ఆఫ్‌లైన్ మోడ్",
        welcomeMessage: "నమస్కారం! నేను మీ అగ్రిబోట్ అసిస్టెంట్‌ని. నేను పంట వ్యాధులు, ఎరువులు, వాతావరణ నవీకరణలు మరియు వ్యవసాయ సర్వోత్తమ పద్ధతులతో మీకు సహాయం చేయగలను. ఈరోజు నేను మీకు ఎలా సహాయం చేయగలను?",
        voicePrompt: "వింటోంది... దయచేసి ఇప్పుడు మాట్లాడండి",
        noInternet: "ఇంటర్నెట్ కనెక్షన్ లేదు. ఆఫ్‌లైన్ చిట్కాలు చూపిస్తోంది."
    }
};

export default function Chatbot() {
    const navigate = useNavigate();
    const [messages, setMessages] = useState([]);
    const [inputText, setInputText] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [language, setLanguage] = useState("english");
    const [voiceEnabled, setVoiceEnabled] = useState(true);
    const [conversationContext, setConversationContext] = useState({});
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        loadChatHistory();
        const savedLanguage = localStorage.getItem("cropguard-language") || "english";
        const savedVoice = localStorage.getItem("cropguard-voice") !== "false";
        setLanguage(savedLanguage);
        setVoiceEnabled(savedVoice);

        // Add welcome message
        const welcomeMessage = {
            id: 'welcome',
            message: translations[savedLanguage].welcomeMessage,
            message_type: 'assistant',
            language: savedLanguage,
            created_date: new Date().toISOString()
        };
        setMessages([welcomeMessage]);

        // Listen for online/offline events
        const handleOnline = () => setIsOnline(true);
        const handleOffline = () => setIsOnline(false);
        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const t = translations[language];

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    const loadChatHistory = async () => {
        try {
            const history = await ChatMessage.list("-created_date", 50);
            setMessages(history.reverse());
        } catch (error) {
            console.error("Error loading chat history:", error);
        }
    };

    const sendMessage = async (messageText, isVoice = false, category = "general") => {
        if (!messageText.trim()) return;

        const userMessage = {
            message: messageText,
            message_type: 'user',
            language: language,
            category: category,
            voice_used: isVoice,
            context_data: conversationContext
        };

        setMessages(prev => [...prev, { ...userMessage, id: Date.now() }]);
        setInputText("");
        setIsLoading(true);

        try {
            if (!isOnline) {
                // Offline response
                const offlineResponse = getOfflineResponse(messageText, category);
                const assistantMessage = {
                    message: offlineResponse,
                    message_type: 'assistant',
                    language: language,
                    category: category
                };
                setMessages(prev => [...prev, { ...assistantMessage, id: Date.now() + 1 }]);
                setIsLoading(false);
                return;
            }

            // Save user message
            await ChatMessage.create(userMessage);

            // Get AI response
            const aiResponse = await getAIResponse(messageText, category);
            
            const assistantMessage = {
                message: aiResponse,
                message_type: 'assistant',
                language: language,
                category: category,
                context_data: conversationContext
            };

            setMessages(prev => [...prev, { ...assistantMessage, id: Date.now() + 1 }]);
            
            // Save assistant message
            await ChatMessage.create(assistantMessage);

        } catch (error) {
            console.error("Error sending message:", error);
            const errorMessage = {
                message: language === 'telugu' 
                    ? "క్షమించండి, ఏదో లోపం జరిగింది. దయచేసి మళ్లీ ప్రయత్నించండి." 
                    : "Sorry, something went wrong. Please try again.",
                message_type: 'assistant',
                language: language,
                category: 'error'
            };
            setMessages(prev => [...prev, { ...errorMessage, id: Date.now() + 1 }]);
        }

        setIsLoading(false);
    };

    const getAIResponse = async (userMessage, category) => {
        let systemPrompt = `You are AgriBot, an expert agriculture assistant helping farmers in ${language === 'telugu' ? 'Telugu' : 'English'}.
        
        Guidelines:
        - Respond in ${language === 'telugu' ? 'Telugu' : 'English'} language only
        - Be farmer-friendly, use simple terms
        - Provide practical, actionable advice
        - Include specific product names, dosages, and safety instructions when recommending pesticides/fertilizers
        - Be concise but thorough
        - Focus on Indian agriculture and crops
        
        Context: This farmer is asking about ${category} related topics.
        Previous conversation context: ${JSON.stringify(conversationContext)}`;

        if (category === 'disease') {
            // Get recent disease analyses for context
            const recentAnalyses = await CropAnalysis.list("-created_date", 5);
            if (recentAnalyses.length > 0) {
                systemPrompt += `\n\nRecent disease analyses from the farmer: ${JSON.stringify(recentAnalyses.map(a => ({
                    crop: a.crop_type,
                    disease: a.disease_detected,
                    severity: a.disease_severity,
                    date: a.created_date
                })))}`;
            }
        }

        const response = await InvokeLLM({
            prompt: `${systemPrompt}\n\nFarmer's question: ${userMessage}`,
            add_context_from_internet: true
        });

        return response;
    };

    const getOfflineResponse = (message, category) => {
        const offlineResponses = {
            english: {
                general: "I'm currently offline, but here are some general farming tips: Water crops early morning or evening, maintain proper spacing between plants, and regularly inspect for pests.",
                disease: "For plant diseases, ensure good air circulation, avoid overhead watering, and use copper-based fungicides as prevention. Consult local agricultural officer when online.",
                fertilizer: "Use balanced NPK fertilizer (19:19:19) for most crops. Apply organic compost regularly. Soil testing helps determine specific needs.",
                weather: "Check local weather patterns. Avoid spraying before rain. Plan irrigation based on seasonal rainfall patterns in your area.",
                irrigation: "Water deeply but less frequently. Check soil moisture at 4-6 inch depth. Use drip irrigation for water conservation."
            },
            telugu: {
                general: "నేను ప్రస్తుతం ఆఫ్‌లైన్‌లో ఉన్నాను, కానీ ఇక్కడ కొన్ని సాధారణ వ్యవసాయ చిట్కాలు ఉన్నాయి: పంటలకు తెల్లవారుజామున లేదా సాయంత్రం నీరు పట్టండి, మొక్కల మధ్య సరైన ఖాళీని కలిగి ఉండండి.",
                disease: "మొక్కల వ్యాధుల కోసం, మంచి గాలి ప్రసరణను నిర్ధారించండి, తలపై నీరు పట్టడం మానుకోండి, నివారణగా రాగి-ఆధారిత శిలీంధ్రనాశకాలను ఉపయోగించండి.",
                fertilizer: "చాలా పంటలకు సమతుల్య NPK ఎరువు (19:19:19) ఉపయోగించండి. సేంద్రీయ కంపోస్ట్‌ను క్రమం తప్పకుండా వర్తించండి.",
                weather: "స్థానిక వాతావరణ పరిస్థితులను తనిఖీ చేయండి. వర్షానికి ముందు స్ప్రే చేయవద్దు. మీ ప్రాంతంలో కాలానుగుణ వర్షపాతం ఆధారంగా నీటిపారుదల ప్లాన్ చేయండి.",
                irrigation: "లోతుగా కానీ తక్కువ తరచుగా నీరు పట్టండి. 4-6 అంగుళాల లోతులో మట్టి తేమను తనిఖీ చేయండి."
            }
        };

        return offlineResponses[language][category] || offlineResponses[language].general;
    };

    const handleVoiceInput = (transcript) => {
        setInputText(transcript);
    };

    const handleQuickAction = (action) => {
        const quickQuestions = {
            english: {
                disease: "What are common crop diseases in my area and how to prevent them?",
                weather: "What's the current weather forecast for farming activities?",
                market: "What are the current market prices for major crops?",
                fertilizer: "What fertilizers should I use for healthy crop growth?",
                irrigation: "What's the best irrigation schedule for my crops?",
                pesticide: "What are safe and effective pesticides for pest control?"
            },
            telugu: {
                disease: "నా ప్రాంతంలో సాధారణ పంట వ్యాధులు ఏమిటి మరియు వాటిని ఎలా నివారించాలి?",
                weather: "వ్యవసాయ కార్యకలాపాలకు ప్రస్తుత వాతావరణ అంచనా ఏమిటి?",
                market: "ప్రధాన పంటలకు ప్రస్తుత మార్కెట్ ధరలు ఎంత?",
                fertilizer: "ఆరోగ్యకరమైన పంట పెరుగుదలకు నేను ఏ ఎరువులు ఉపయోగించాలి?",
                irrigation: "నా పంటలకు ఉత్తమమైన నీటిపారుదల షెడ్యూల్ ఏమిటి?",
                pesticide: "పురుగుల నియంత్రణకు సురక్షితమైన మరియు ప్రభావవంతమైన పురుగుమందులు ఏమిటి?"
            }
        };

        const question = quickQuestions[language][action];
        if (question) {
            sendMessage(question, false, action);
        }
    };

    return (
        <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--bg-cream)' }}>
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center gap-4 mb-6">
                    <Button
                        variant="outline"
                        size="icon"
                        onClick={() => navigate(createPageUrl("Dashboard"))}
                        className="farmer-card"
                    >
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div className="flex-1">
                        <h1 className="text-2xl md:text-3xl font-bold text-green-800 flex items-center gap-2">
                            <Bot className="w-8 h-8" />
                            {t.title}
                        </h1>
                        <p className="text-gray-600 mt-1">{t.subtitle}</p>
                    </div>
                    {!isOnline && (
                        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            {t.offlineMode}
                        </Badge>
                    )}
                </div>

                <div className="grid lg:grid-cols-4 gap-6">
                    {/* Main Chat Area */}
                    <div className="lg:col-span-3">
                        <Card className="farmer-card h-[600px] flex flex-col">
                            <CardHeader className="flex-shrink-0 gradient-bg text-white">
                                <CardTitle className="flex items-center gap-2 text-lg">
                                    <MessageCircle className="w-5 h-5" />
                                    AgriBot Chat
                                </CardTitle>
                            </CardHeader>
                            
                            {/* Messages Area */}
                            <CardContent className="flex-1 flex flex-col p-0">
                                <ScrollArea className="flex-1 p-4">
                                    <AnimatePresence>
                                        {messages.map((message, index) => (
                                            <ChatMessageBubble
                                                key={message.id || index}
                                                message={message}
                                                language={language}
                                                voiceEnabled={voiceEnabled}
                                            />
                                        ))}
                                    </AnimatePresence>
                                    
                                    {isLoading && (
                                        <motion.div
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            className="flex justify-start mb-4"
                                        >
                                            <div className="bg-green-50 border border-green-200 rounded-xl p-3 max-w-xs">
                                                <div className="flex items-center gap-2">
                                                    <Bot className="w-4 h-4 text-green-600" />
                                                    <Loader2 className="w-4 h-4 animate-spin text-green-600" />
                                                    <span className="text-sm text-green-700">Thinking...</span>
                                                </div>
                                            </div>
                                        </motion.div>
                                    )}
                                    
                                    <div ref={messagesEndRef} />
                                </ScrollArea>

                                {/* Input Area */}
                                <div className="border-t p-4">
                                    <div className="flex gap-2">
                                        <div className="flex-1 relative">
                                            <Input
                                                value={inputText}
                                                onChange={(e) => setInputText(e.target.value)}
                                                placeholder={t.typePlaceholder}
                                                onKeyPress={(e) => e.key === 'Enter' && sendMessage(inputText)}
                                                className="pr-12"
                                                disabled={isLoading}
                                            />
                                            {voiceEnabled && (
                                                <div className="absolute right-2 top-1/2 -translate-y-1/2">
                                                    <VoiceInputButton
                                                        onTranscript={handleVoiceInput}
                                                        language={language}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                        <Button
                                            onClick={() => sendMessage(inputText)}
                                            disabled={isLoading || !inputText.trim()}
                                            className="bg-green-600 hover:bg-green-700"
                                        >
                                            <Send className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-6">
                        <QuickActionButtons 
                            onAction={handleQuickAction}
                            language={language}
                        />
                        
                        <WeatherCard language={language} />
                        
                        <OfflineTipsCard 
                            language={language}
                            isOnline={isOnline}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}