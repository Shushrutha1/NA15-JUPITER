import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Languages, Volume2, VolumeX, Bell, User, Globe, Smartphone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

export default function Settings() {
  const navigate = useNavigate();
  const [language, setLanguage] = useState("english");
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [autoCapture, setAutoCapture] = useState(false);

  const translations = {
    english: {
      title: "Settings",
      subtitle: "Customize your CropGuard AI experience",
      languageSettings: "Language Settings",
      languageDesc: "Choose your preferred language",
      currentLang: "Current Language",
      english: "English",
      telugu: "Telugu",
      voiceSettings: "Voice Assistant",
      voiceDesc: "Enable voice recommendations and audio guidance",
      voiceEnabled: "Voice Assistant Enabled",
      notificationSettings: "Notifications",
      notificationDesc: "Get alerts about crop health and recommendations",
      notificationsEnabled: "Push Notifications",
      captureSettings: "Camera Settings",
      captureDesc: "Camera and photo capture preferences",
      autoCapture: "Auto Capture Mode",
      autoCaptureDesc: "Automatically analyze photos after capture",
      about: "About CropGuard AI",
      version: "Version 1.0.0",
      aboutDesc: "Smart crop protection powered by artificial intelligence"
    },
    telugu: {
      title: "సెట్టింగ్‌లు",
      subtitle: "మీ క్రాప్‌గార్డ్ AI అనుభవాన్ని అనుకూలీకరించండి",
      languageSettings: "భాష సెట్టింగ్‌లు",
      languageDesc: "మీ ప్రాధాన్య భాషను ఎంచుకోండి",
      currentLang: "ప్రస్తుత భాష",
      english: "ఇంగ్లీష్",
      telugu: "తెలుగు",
      voiceSettings: "వాయిస్ అసిస్టెంట్",
      voiceDesc: "వాయిస్ సిఫార్సులు మరియు ఆడియో గైడెన్స్‌ని ప్రారంభించండి",
      voiceEnabled: "వాయిస్ అసిస్టెంట్ ప్రారంభించబడింది",
      notificationSettings: "నోటిఫికేషన్‌లు",
      notificationDesc: "పంట ఆరోగ్యం మరియు సిఫార్సుల గురించి అలర్ట్‌లను పొందండి",
      notificationsEnabled: "పుష్ నోటిఫికేషన్‌లు",
      captureSettings: "కెమెరా సెట్టింగ్‌లు",
      captureDesc: "కెమెరా మరియు ఫోటో క్యాప్చర్ ప్రాధాన్యతలు",
      autoCapture: "ఆటో క్యాప్చర్ మోడ్",
      autoCaptureDesc: "క్యాప్చర్ చేసిన తర్వాత ఫోటోలను స్వయంచాలకంగా విశ్లేషించండి",
      about: "క్రాప్‌గార్డ్ AI గురించి",
      version: "వెర్షన్ 1.0.0",
      aboutDesc: "కృత్రిమ మేధస్సుతో నడిచే స్మార్ట్ పంట రక్షణ"
    }
  };

  useEffect(() => {
    const savedLanguage = localStorage.getItem("cropguard-language") || "english";
    const savedVoice = localStorage.getItem("cropguard-voice") === "true";
    const savedNotifications = localStorage.getItem("cropguard-notifications") !== "false";
    const savedAutoCapture = localStorage.getItem("cropguard-auto-capture") === "true";

    setLanguage(savedLanguage);
    setVoiceEnabled(savedVoice);
    setNotifications(savedNotifications);
    setAutoCapture(savedAutoCapture);
  }, []);

  const t = translations[language];

  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
    localStorage.setItem("cropguard-language", newLanguage);
    // Force a page refresh to apply language changes
    setTimeout(() => window.location.reload(), 100);
  };

  const handleVoiceToggle = (enabled) => {
    setVoiceEnabled(enabled);
    localStorage.setItem("cropguard-voice", enabled.toString());
  };

  const handleNotificationsToggle = (enabled) => {
    setNotifications(enabled);
    localStorage.setItem("cropguard-notifications", enabled.toString());
  };

  const handleAutoCaptureToggle = (enabled) => {
    setAutoCapture(enabled);
    localStorage.setItem("cropguard-auto-capture", enabled.toString());
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--bg-cream)' }}>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="farmer-card"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-green-800">{t.title}</h1>
            <p className="text-gray-600 mt-1">{t.subtitle}</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Language Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="farmer-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <Languages className="w-5 h-5" />
                  {t.languageSettings}
                </CardTitle>
                <p className="text-gray-600 text-sm">{t.languageDesc}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.currentLang}</p>
                    <Badge variant="outline" className="mt-1">
                      {language === "english" ? t.english : t.telugu}
                    </Badge>
                  </div>
                  <Select value={language} onValueChange={handleLanguageChange}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">
                        <div className="flex items-center gap-2">
                          <Globe className="w-4 h-4" />
                          English
                        </div>
                      </SelectItem>
                      <SelectItem value="telugu">
                        <div className="flex items-center gap-2">
                          <Globe className="w-4 h-4" />
                          తెలుగు (Telugu)
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Voice Assistant Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="farmer-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                  {t.voiceSettings}
                </CardTitle>
                <p className="text-gray-600 text-sm">{t.voiceDesc}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.voiceEnabled}</p>
                    <Badge variant={voiceEnabled ? "default" : "secondary"} className="mt-1">
                      {voiceEnabled ? "ON" : "OFF"}
                    </Badge>
                  </div>
                  <Switch
                    checked={voiceEnabled}
                    onCheckedChange={handleVoiceToggle}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Notification Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="farmer-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <Bell className="w-5 h-5" />
                  {t.notificationSettings}
                </CardTitle>
                <p className="text-gray-600 text-sm">{t.notificationDesc}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.notificationsEnabled}</p>
                    <Badge variant={notifications ? "default" : "secondary"} className="mt-1">
                      {notifications ? "ON" : "OFF"}
                    </Badge>
                  </div>
                  <Switch
                    checked={notifications}
                    onCheckedChange={handleNotificationsToggle}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Camera Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="farmer-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <Smartphone className="w-5 h-5" />
                  {t.captureSettings}
                </CardTitle>
                <p className="text-gray-600 text-sm">{t.captureDesc}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.autoCapture}</p>
                    <p className="text-sm text-gray-600">{t.autoCaptureDesc}</p>
                    <Badge variant={autoCapture ? "default" : "secondary"} className="mt-1">
                      {autoCapture ? "ON" : "OFF"}
                    </Badge>
                  </div>
                  <Switch
                    checked={autoCapture}
                    onCheckedChange={handleAutoCaptureToggle}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* About Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="farmer-card gradient-bg text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16" />
              <CardHeader className="relative z-10">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  {t.about}
                </CardTitle>
              </CardHeader>
              <CardContent className="relative z-10">
                <div className="space-y-3">
                  <div>
                    <p className="font-medium">{t.version}</p>
                    <p className="text-green-100 text-sm">{t.aboutDesc}</p>
                  </div>
                  <div className="pt-4 border-t border-white/20">
                    <p className="text-green-100 text-sm">
                      Powered by advanced AI technology for accurate crop disease detection and treatment recommendations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}