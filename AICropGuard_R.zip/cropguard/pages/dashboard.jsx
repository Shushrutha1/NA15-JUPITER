
import React, { useState, useEffect } from "react";
import { CropAnalysis } from "@/entities/CropAnalysis";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
    Camera, 
    TrendingUp, 
    AlertTriangle, 
    CheckCircle, 
    Leaf,
    History,
    Zap,
    Shield,
    MessageCircle, // New import for AI Assistant icon
    Bot // New import for AI Assistant badge icon
} from "lucide-react";
import { motion } from "framer-motion";

import QuickStats from "../components/dashboard/QuickStats";
import RecentScans from "../components/dashboard/recentscans.jsx";
import HealthTips from "../components/dashboard/HealthTips";
import WeatherWidget from "../components/dashboard/WeatherWidget";

export default function Dashboard() {
  const [analyses, setAnalyses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [language, setLanguage] = useState("english");

  const translations = {
    english: {
      title: "Welcome to CropGuard AI",
      subtitle: "Protect your crops with smart disease detection",
      scanCrop: "Scan Your Crop",
      scanSubtitle: "Take a photo to detect diseases instantly",
      askAI: "Ask AI Assistant", // New translation key
      aiSubtitle: "Get instant answers to your farming questions", // New translation key
      viewHistory: "View History",
      historySubtitle: "See all your previous scans",
      quickActions: "Quick Actions",
      recentActivity: "Recent Activity",
      cropHealth: "Crop Health Tips",
      weather: "Weather Updates"
    },
    telugu: {
      title: "క్రాప్‌గార్డ్ AI కి స్వాగతం",
      subtitle: "స్మార్ట్ వ్యాధి గుర్తింపుతో మీ పంటలను రక్షించండి",
      scanCrop: "మీ పంటను స్కాన్ చేయండి",
      scanSubtitle: "వ్యాధులను తక్షణం గుర్తించడానికి ఫోటో తీయండి",
      askAI: "AI అసిస్టెంట్‌ని అడగండి", // New translation key
      aiSubtitle: "మీ వ్యవసాయ ప్రశ్నలకు తక్షణ సమాధానాలు పొందండి", // New translation key
      viewHistory: "చరిత్రను చూడండి",
      historySubtitle: "మీ మునుపటి స్కాన్‌లన్నింటినీ చూడండి",
      quickActions: "త్వరిత చర్యలు",
      recentActivity: "ఇటీవలి కార్యకలాపాలు",
      cropHealth: "పంట ఆరోగ్య చిట్కాలు",
      weather: "వాతావరణ వార్తలు"
    }
  };

  useEffect(() => {
    loadAnalyses();
    const savedLanguage = localStorage.getItem("cropguard-language") || "english";
    setLanguage(savedLanguage);
  }, []);

  const loadAnalyses = async () => {
    setIsLoading(true);
    try {
      const data = await CropAnalysis.list("-created_date", 10);
      setAnalyses(data);
    } catch (error) {
      console.error("Error loading analyses:", error);
    }
    setIsLoading(false);
  };

  const t = translations[language];

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--bg-cream)' }}>
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="gradient-bg rounded-3xl p-8 mb-8 text-white relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <Leaf className="w-12 h-12" />
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">{t.title}</h1>
                <p className="text-green-100 text-lg mt-2">{t.subtitle}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold text-green-800 mb-6">{t.quickActions}</h2>
          <div className="grid md:grid-cols-3 gap-6"> {/* Changed grid-cols-2 to grid-cols-3 */}
            <Link to={createPageUrl("CameraCapture")} className="block">
              <Card className="farmer-card h-full cursor-pointer group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 mx-auto mb-6 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <Camera className="w-10 h-10 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-green-800 mb-2">{t.scanCrop}</h3>
                  <p className="text-gray-600">{t.scanSubtitle}</p>
                  <div className="flex items-center justify-center gap-2 mt-4">
                    <Badge className="bg-green-500 hover:bg-green-600">
                      <Zap className="w-3 h-3 mr-1" />
                      AI Powered
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>

            {/* New AI Assistant Card */}
            <Link to={createPageUrl("Chatbot")} className="block">
              <Card className="farmer-card h-full cursor-pointer group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 mx-auto mb-6 bg-purple-100 rounded-full flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <MessageCircle className="w-10 h-10 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-green-800 mb-2">{t.askAI}</h3>
                  <p className="text-gray-600">{t.aiSubtitle}</p>
                  <div className="flex items-center justify-center gap-2 mt-4">
                    <Badge className="bg-purple-500 hover:bg-purple-600">
                      <Bot className="w-3 h-3 mr-1" />
                      Smart Chat
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
            {/* End New AI Assistant Card */}

            <Link to={createPageUrl("History")} className="block">
              <Card className="farmer-card h-full cursor-pointer group">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 mx-auto mb-6 bg-blue-100 rounded-full flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <History className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-green-800 mb-2">{t.viewHistory}</h3>
                  <p className="text-gray-600">{t.historySubtitle}</p>
                  <div className="flex items-center justify-center gap-2 mt-4">
                    <Badge variant="secondary">
                      <Shield className="w-3 h-3 mr-1" />
                      Track Progress
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </div>
        </motion.div>

        {/* Stats and Activity Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 space-y-8">
            <QuickStats analyses={analyses} isLoading={isLoading} language={language} />
            <RecentScans analyses={analyses} isLoading={isLoading} language={language} />
          </div>
          
          <div className="space-y-8">
            <WeatherWidget language={language} />
            <HealthTips language={language} />
          </div>
        </div>
      </div>
    </div>
  );
}
