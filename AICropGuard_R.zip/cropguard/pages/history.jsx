
import React, { useState, useEffect } from "react";
import { CropAnalysis } from "@/entities/CropAnalysis";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Search, Filter, Calendar, AlertTriangle, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function History() {
  const navigate = useNavigate();
  const [analyses, setAnalyses] = useState([]);
  const [filteredAnalyses, setFilteredAnalyses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterCrop, setFilterCrop] = useState("all");
  const [language, setLanguage] = useState("english");

  const translations = {
    english: {
      title: "Scan History",
      subtitle: "View all your previous crop analyses",
      search: "Search by crop type or disease...",
      filterSeverity: "Filter by Severity",
      filterCrop: "Filter by Crop Type",
      allSeverity: "All Severities",
      allCrops: "All Crops",
      healthy: "Healthy",
      diseased: "Disease Detected",
      noResults: "No scan history found",
      noResultsDesc: "Start scanning your crops to build your history",
      confidence: "Confidence"
    },
    telugu: {
      title: "స్కాన్ చరిత్ర",
      subtitle: "మీ మునుపటి పంట విశ్లేషణలన్నింటినీ చూడండి",
      search: "పంట రకం లేదా వ్యాధి ద్వారా శోధించండి...",
      filterSeverity: "తీవ్రత ద్వారా ఫిల్టర్ చేయండి",
      filterCrop: "పంట రకం ద్వారా ఫిల్టర్ చేయండి",
      allSeverity: "అన్ని తీవ్రతలు",
      allCrops: "అన్ని పంటలు",
      healthy: "ఆరోగ్యకరం",
      diseased: "వ్యాధి గుర్తించబడింది",
      noResults: "స్కాన్ చరిత్ర కనుగొనబడలేదు",
      noResultsDesc: "మీ చరిత్రను నిర్మించడానికి మీ పంటలను స్కాన్ చేయడం ప్రారంభించండి",
      confidence: "విశ్వాసం"
    }
  };

  useEffect(() => {
    loadAnalyses();
    const savedLanguage = localStorage.getItem("cropguard-language") || "english";
    setLanguage(savedLanguage);
  }, []);

  useEffect(() => {
    // Filter results logic moved inside useEffect to fix dependency warning
    let filtered = analyses;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(analysis =>
        analysis.crop_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        analysis.disease_detected?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Severity filter
    if (filterSeverity !== "all") {
      if (filterSeverity === "healthy") {
        filtered = filtered.filter(analysis => 
          !analysis.disease_detected || analysis.disease_severity === 'low'
        );
      } else {
        filtered = filtered.filter(analysis => 
          analysis.disease_severity === filterSeverity
        );
      }
    }

    // Crop type filter
    if (filterCrop !== "all") {
      filtered = filtered.filter(analysis => analysis.crop_type === filterCrop);
    }

    setFilteredAnalyses(filtered);
  }, [searchTerm, filterSeverity, filterCrop, analyses]);

  const t = translations[language];

  const loadAnalyses = async () => {
    setIsLoading(true);
    try {
      const data = await CropAnalysis.list("-created_date");
      setAnalyses(data);
    } catch (error) {
      console.error("Error loading analyses:", error);
    }
    setIsLoading(false);
  };

  const getSeverityColor = (severity, diseaseDetected) => {
    if (!diseaseDetected || severity === 'low') {
      return 'bg-green-100 text-green-800 border-green-300';
    }
    switch (severity) {
      case 'moderate': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'critical': return 'bg-red-200 text-red-900 border-red-400';
      default: return 'bg-green-100 text-green-800 border-green-300';
    }
  };

  const getUniqueValues = (key) => {
    return [...new Set(analyses.map(a => a[key]).filter(Boolean))];
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--bg-cream)' }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="farmer-card"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-green-800">{t.title}</h1>
            <p className="text-gray-600 mt-1">{t.subtitle}</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="farmer-card mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder={t.search}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                <SelectTrigger>
                  <SelectValue placeholder={t.filterSeverity} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t.allSeverity}</SelectItem>
                  <SelectItem value="healthy">{t.healthy}</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="moderate">Moderate</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterCrop} onValueChange={setFilterCrop}>
                <SelectTrigger>
                  <SelectValue placeholder={t.filterCrop} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t.allCrops}</SelectItem>
                  {getUniqueValues("crop_type").map(crop => (
                    <SelectItem key={crop} value={crop}>
                      {crop.charAt(0).toUpperCase() + crop.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex items-center text-sm text-gray-600">
                <Filter className="w-4 h-4 mr-2" />
                {filteredAnalyses.length} results
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <Card key={i} className="farmer-card animate-pulse">
                <CardContent className="p-6">
                  <div className="aspect-square bg-gray-200 rounded-xl mb-4" />
                  <div className="h-4 bg-gray-200 rounded mb-2" />
                  <div className="h-3 bg-gray-200 rounded w-3/4 mb-2" />
                  <div className="h-3 bg-gray-200 rounded w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredAnalyses.length === 0 ? (
          <Card className="farmer-card text-center py-12">
            <CardContent>
              <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">{t.noResults}</h3>
              <p className="text-gray-500 mb-6">{t.noResultsDesc}</p>
              <Button
                onClick={() => navigate(createPageUrl("CameraCapture"))}
                className="bg-green-600 hover:bg-green-700"
              >
                Start Scanning
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAnalyses.map((analysis, index) => (
              <motion.div
                key={analysis.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="farmer-card h-full group cursor-pointer hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="relative mb-4">
                      <img
                        src={analysis.image_url}
                        alt="Crop scan"
                        className="w-full aspect-square object-cover rounded-xl"
                      />
                      <div className="absolute top-2 right-2">
                        {analysis.disease_detected && analysis.disease_severity !== 'low' ? (
                          <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                            <AlertTriangle className="w-4 h-4 text-white" />
                          </div>
                        ) : (
                          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <h3 className="font-semibold text-green-800 capitalize">
                          {analysis.crop_type}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {analysis.disease_detected || t.healthy}
                        </p>
                      </div>

                      <div className="flex items-center justify-between">
                        <Badge className={`${getSeverityColor(analysis.disease_severity, analysis.disease_detected)} border`}>
                          {analysis.disease_detected && analysis.disease_severity !== 'low' 
                            ? t.diseased 
                            : t.healthy
                          }
                        </Badge>
                        <Badge variant="outline">
                          {t.confidence}: {Math.round(analysis.confidence_score || 85)}%
                        </Badge>
                      </div>

                      <p className="text-xs text-gray-500 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(analysis.created_date), "MMM d, yyyy HH:mm")}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
