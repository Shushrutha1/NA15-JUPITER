
import React, { useState, useRef } from "react";
import { CropAnalysis } from "@/entities/CropAnalysis";
import { UploadFile, InvokeLLM } from "@/integrations/Core";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Camera, Upload, Loader2, ArrowLeft, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import CameraInterface from "../components/camera/CameraInterface";
import ImagePreview from "../components/camera/ImagePreview";
import AnalysisResults from "../components/camera/AnalysisResults";

export default function CameraCapture() {
  const navigate = useNavigate();
  const [step, setStep] = useState("capture"); // capture, preview, analyze, results
  const [selectedImage, setSelectedImage] = useState(null);
  const [cropType, setCropType] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [analysisResults, setAnalysisResults] = useState(null);
  const [error, setError] = useState(null);
  const [language, setLanguage] = useState("english");
  const [voiceEnabled, setVoiceEnabled] = useState(true); // New state for voice
  const fileInputRef = useRef(null);

  const cropTypes = [
    "rice", "wheat", "corn", "cotton", "sugarcane", "tomato", "potato", "onion", 
    "cabbage", "carrot", "spinach", "brinjal", "okra", "chili", "other"
  ];

  const translations = {
    english: {
      title: "Crop Disease Detection",
      subtitle: "Capture or upload a photo of your crop for instant AI analysis",
      takePicture: "Take Picture",
      uploadPhoto: "Upload Photo",
      cropType: "Select Crop Type",
      selectCrop: "Choose your crop type",
      analyze: "Analyze Crop",
      analyzing: "Analyzing your crop...",
      backToDashboard: "Back to Dashboard",
      retakePhoto: "Retake Photo",
      uploadAnother: "Upload Another",
      analysisComplete: "Analysis Complete!"
    },
    telugu: {
      title: "పంట వ్యాధి గుర్తింపు",
      subtitle: "తక్షణ AI విశ్లేషణ కోసం మీ పంట ఫోటోను తీయండి లేదా అప్‌లోడ్ చేయండి",
      takePicture: "ఫోటో తీయండి",
      uploadPhoto: "ఫోటో అప్‌లోడ్ చేయండి",
      cropType: "పంట రకాన్ని ఎంచుకోండి",
      selectCrop: "మీ పంట రకాన్ని ఎంచుకోండి",
      analyze: "పంటను విశ్లేషించండి",
      analyzing: "మీ పంటను విశ్లేషిస్తోంది...",
      backToDashboard: "డాష్‌బోర్డ్‌కు తిరిగి వెళ్లండి",
      retakePhoto: "మళ్లీ ఫోటో తీయండి",
      uploadAnother: "మరొకటి అప్‌లోడ్ చేయండి",
      analysisComplete: "విశ్లేషణ పూర్తైంది!"
    }
  };

  React.useEffect(() => {
    const savedLanguage = localStorage.getItem("cropguard-language") || "english";
    setLanguage(savedLanguage);
    const savedVoice = localStorage.getItem("cropguard-voice") !== "false"; // Load voice preference
    setVoiceEnabled(savedVoice);
  }, []);

  const t = translations[language];

  const handleImageCapture = (imageFile) => {
    setSelectedImage(imageFile);
    setStep("preview");
    setError(null);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type.startsWith("image/")) {
        handleImageCapture(file);
      } else {
        setError("Please select an image file (PNG, JPG, JPEG)");
      }
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage || !cropType) return;

    setIsAnalyzing(true);
    setAnalysisProgress(0);
    setStep("analyze");
    setError(null);

    try {
      // Progress simulation
      const progressInterval = setInterval(() => {
        setAnalysisProgress((prev) => {
          if (prev >= 90) return prev;
          return prev + 10;
        });
      }, 200);

      // Upload image
      const { file_url } = await UploadFile({ file: selectedImage });
      setAnalysisProgress(30);

      // AI Analysis
      const analysisPrompt = `
        Analyze this ${cropType} crop image for diseases and health issues.
        Look for visual signs of diseases, pests, nutrient deficiencies, or other problems.
        Provide detailed analysis in ${language === "telugu" ? "Telugu" : "English"} language.
        
        Response should include:
        1. Disease identification (if any)
        2. Severity level (low, moderate, high, critical)
        3. Confidence score (0-100)
        4. Detailed symptoms observed
        5. Possible causes
        6. Treatment recommendations with specific pesticides/fungicides
        7. Prevention tips for future
        
        Be very specific about pesticide names, dosages, and application methods.
        If the crop looks healthy, mention that clearly.
      `;

      const analysisResult = await InvokeLLM({
        prompt: analysisPrompt,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            disease_detected: { type: "string" },
            disease_severity: { type: "string", enum: ["low", "moderate", "high", "critical"] },
            confidence_score: { type: "number" },
            symptoms: { 
              type: "array",
              items: { type: "string" }
            },
            analysis_details: {
              type: "object",
              properties: {
                disease_description: { type: "string" },
                causes: {
                  type: "array",
                  items: { type: "string" }
                },
                prevention_tips: {
                  type: "array",
                  items: { type: "string" }
                }
              }
            },
            pesticide_recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  active_ingredient: { type: "string" },
                  application_method: { type: "string" },
                  dosage: { type: "string" },
                  frequency: { type: "string" },
                  safety_instructions: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            }
          }
        }
      });

      clearInterval(progressInterval);
      setAnalysisProgress(100);

      // Save to database
      const analysisData = {
        image_url: file_url,
        crop_type: cropType,
        language: language,
        ...analysisResult
      };

      const savedAnalysis = await CropAnalysis.create(analysisData);
      setAnalysisResults(savedAnalysis);
      setStep("results");

    } catch (error) {
      setError("Failed to analyze the image. Please try again.");
      console.error("Analysis error:", error);
      setStep("preview");
    }

    setIsAnalyzing(false);
  };

  const resetCapture = () => {
    setSelectedImage(null);
    setCropType("");
    setAnalysisResults(null);
    setError(null);
    setStep("capture");
    setAnalysisProgress(0);
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{ backgroundColor: 'var(--bg-cream)' }}>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="farmer-card"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-green-800">{t.title}</h1>
            <p className="text-gray-600 mt-1">{t.subtitle}</p>
          </div>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <AnimatePresence mode="wait">
          {step === "capture" && (
            <motion.div
              key="capture"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <CameraInterface 
                onImageCapture={handleImageCapture}
                onFileUpload={handleFileUpload}
                fileInputRef={fileInputRef}
                language={language}
              />
            </motion.div>
          )}

          {step === "preview" && (
            <motion.div
              key="preview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <ImagePreview
                image={selectedImage}
                cropType={cropType}
                setCropType={setCropType}
                cropTypes={cropTypes}
                onAnalyze={analyzeImage}
                onRetake={resetCapture}
                language={language}
              />
            </motion.div>
          )}

          {step === "analyze" && (
            <motion.div
              key="analyze"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <Card className="farmer-card max-w-md mx-auto">
                <CardContent className="p-8">
                  <Loader2 className="w-16 h-16 animate-spin text-green-600 mx-auto mb-6" />
                  <h3 className="text-xl font-bold text-green-800 mb-2">{t.analyzing}</h3>
                  <Progress value={analysisProgress} className="mb-4" />
                  <p className="text-gray-600">Please wait while AI analyzes your crop...</p>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === "results" && analysisResults && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <AnalysisResults
                analysis={analysisResults}
                onNewScan={resetCapture}
                language={language}
                voiceEnabled={voiceEnabled} // Pass voiceEnabled to AnalysisResults
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
