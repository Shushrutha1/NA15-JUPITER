import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, 
  Cloud, 
  TrendingUp, 
  Droplets, 
  Sprout, 
  Shield 
} from 'lucide-react';

export default function QuickActionButtons({ onAction, language }) {
  const translations = {
    english: {
      quickActions: "Quick Actions",
      disease: "Disease Help",
      weather: "Weather Info",
      market: "Market Prices",
      fertilizer: "Fertilizers",
      irrigation: "Irrigation",
      pesticide: "Pesticides"
    },
    telugu: {
      quickActions: "త్వరిత చర్యలు",
      disease: "వ్యాధి సహాయం",
      weather: "వాతావరణ సమాచారం",
      market: "మార్కెట్ ధరలు",
      fertilizer: "ఎరువులు",
      irrigation: "నీటిపారుదల",
      pesticide: "పురుగుమందులు"
    }
  };

  const t = translations[language];

  const actions = [
    { id: 'disease', icon: AlertTriangle, label: t.disease, color: 'bg-red-100 text-red-600' },
    { id: 'weather', icon: Cloud, label: t.weather, color: 'bg-blue-100 text-blue-600' },
    { id: 'market', icon: TrendingUp, label: t.market, color: 'bg-purple-100 text-purple-600' },
    { id: 'fertilizer', icon: Sprout, label: t.fertilizer, color: 'bg-green-100 text-green-600' },
    { id: 'irrigation', icon: Droplets, label: t.irrigation, color: 'bg-cyan-100 text-cyan-600' },
    { id: 'pesticide', icon: Shield, label: t.pesticide, color: 'bg-orange-100 text-orange-600' }
  ];

  return (
    <Card className="farmer-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-green-800 text-lg">{t.quickActions}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {actions.map((action) => (
            <Button
              key={action.id}
              variant="outline"
              className="farmer-card h-auto p-3 flex flex-col gap-2 hover:shadow-md transition-all"
              onClick={() => onAction(action.id)}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${action.color}`}>
                <action.icon className="w-4 h-4" />
              </div>
              <span className="text-xs text-center leading-tight">{action.label}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}