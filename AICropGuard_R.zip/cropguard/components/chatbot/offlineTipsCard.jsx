import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Wifi, WifiOff } from 'lucide-react';

export default function OfflineTipsCard({ language, isOnline }) {
  const translations = {
    english: {
      tips: "Farming Tips",
      offlineTips: "Offline Tips",
      onlineStatus: "Online",
      offlineStatus: "Offline Mode",
      tips: [
        "Water crops early morning or evening",
        "Check soil moisture before irrigation", 
        "Rotate crops to maintain soil health",
        "Use organic compost regularly",
        "Monitor plants for pest signs daily"
      ]
    },
    telugu: {
      tips: "వ్యవసాయ చిట్కాలు",
      offlineTips: "ఆఫ్‌లైన్ చిట్కాలు",
      onlineStatus: "ఆన్‌లైన్",
      offlineStatus: "ఆఫ్‌లైన్ మోడ్",
      tips: [
        "పంటలకు తెల్లవారుజామున లేదా సాయంత్రం నీరు పట్టండి",
        "నీటిపారుదలకు ముందు మట్టి తేమను తనిఖీ చేయండి",
        "మట్టి ఆరోగ్యాన్ని నిర్వహించడానికి పంటలను మార్చండి",
        "సేంద్రీయ కంపోస్ట్‌ను క్రమం తప్పకుండా ఉపయోగించండి",
        "రోజూ మొక్కలను చీడపీడల లక్షణాలను పరిశీలించండి"
      ]
    }
  };

  const t = translations[language];

  return (
    <Card className="farmer-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-green-800 text-lg flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            {isOnline ? t.tips : t.offlineTips}
          </CardTitle>
          <Badge variant={isOnline ? "default" : "secondary"} className="flex items-center gap-1">
            {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            {isOnline ? t.onlineStatus : t.offlineStatus}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {t.tips.map((tip, index) => (
            <div key={index} className="flex items-start gap-2 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" />
              <span className="text-gray-700">{tip}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}