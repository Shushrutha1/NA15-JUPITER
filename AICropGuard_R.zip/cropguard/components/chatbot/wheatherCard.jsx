import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cloud, Thermometer, Droplets, Wind } from 'lucide-react';

export default function WeatherCard({ language }) {
  const translations = {
    english: {
      weather: "Weather Today",
      temperature: "Temperature",
      humidity: "Humidity",
      wind: "Wind Speed",
      condition: "Partly Cloudy",
      farmingCondition: "Good for farming",
      location: "Your Area"
    },
    telugu: {
      weather: "ఈరోజు వాతావరణం",
      temperature: "ఉష్ణోగ్రత",
      humidity: "తేమ",
      wind: "గాలి వేగం",
      condition: "పాక్షిక మేఘావృతం",
      farmingCondition: "వ్యవసాయానికి మంచిది",
      location: "మీ ప్రాంతం"
    }
  };

  const t = translations[language];

  // Mock weather data - in real app, fetch from weather API
  const weatherData = {
    temperature: 28,
    humidity: 65,
    windSpeed: 8,
    condition: t.condition
  };

  return (
    <Card className="farmer-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-green-800 text-lg flex items-center gap-2">
          <Cloud className="w-5 h-5" />
          {t.weather}
        </CardTitle>
        <p className="text-sm text-gray-600">{t.location}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-red-500" />
            <span className="text-sm">{t.temperature}</span>
          </div>
          <span className="font-semibold">{weatherData.temperature}°C</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-500" />
            <span className="text-sm">{t.humidity}</span>
          </div>
          <span className="font-semibold">{weatherData.humidity}%</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wind className="w-4 h-4 text-gray-500" />
            <span className="text-sm">{t.wind}</span>
          </div>
          <span className="font-semibold">{weatherData.windSpeed} km/h</span>
        </div>

        <div className="pt-2 border-t">
          <Badge className="bg-green-100 text-green-800 border-green-300">
            {t.farmingCondition}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}