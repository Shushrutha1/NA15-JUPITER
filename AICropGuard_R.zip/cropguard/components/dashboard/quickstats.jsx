import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, AlertTriangle, CheckCircle, Scan } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

export default function QuickStats({ analyses, isLoading, language }) {
  const translations = {
    english: {
      totalScans: "Total Scans",
      healthyScans: "Healthy Crops",
      diseaseDetected: "Diseases Found",
      thisWeek: "This Week"
    },
    telugu: {
      totalScans: "మొత్తం స్కాన్‌లు",
      healthyScans: "ఆరోగ్యకర పంటలు",
      diseaseDetected: "వ్యాధులు కనుగొనబడ్డాయి",
      thisWeek: "ఈ వారం"
    }
  };

  const t = translations[language];

  const totalScans = analyses.length;
  const healthyScans = analyses.filter(a => a.disease_severity === 'low' || !a.disease_detected).length;
  const diseasedScans = analyses.filter(a => a.disease_detected && a.disease_severity !== 'low').length;

  const statsData = [
    {
      title: t.totalScans,
      value: totalScans,
      icon: Scan,
      color: "bg-blue-500",
      bgColor: "bg-blue-50",
      textColor: "text-blue-600"
    },
    {
      title: t.healthyScans,
      value: healthyScans,
      icon: CheckCircle,
      color: "bg-green-500",
      bgColor: "bg-green-50",
      textColor: "text-green-600"
    },
    {
      title: t.diseaseDetected,
      value: diseasedScans,
      icon: AlertTriangle,
      color: "bg-red-500",
      bgColor: "bg-red-50",
      textColor: "text-red-600"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {statsData.map((stat, index) => (
          <Card key={stat.title} className="farmer-card relative overflow-hidden">
            <div className={`absolute top-0 right-0 w-24 h-24 ${stat.bgColor} rounded-full -translate-y-8 translate-x-8 opacity-50`} />
            <CardContent className="p-6 relative z-10">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 ${stat.textColor}`} />
                </div>
                <TrendingUp className={`w-5 h-5 ${stat.textColor}`} />
              </div>
              
              {isLoading ? (
                <div>
                  <Skeleton className="h-8 w-16 mb-2" />
                  <Skeleton className="h-4 w-24" />
                </div>
              ) : (
                <div>
                  <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                  <Badge variant="outline" className="mt-2 text-xs">
                    {t.thisWeek}
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </motion.div>
  );
}