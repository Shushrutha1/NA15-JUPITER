import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cloud, Sun, CloudRain, Thermometer } from "lucide-react";
import { motion } from "framer-motion";

export default function WeatherWidget({ language }) {
  const translations = {
    english: {
      weather: "Weather Updates",
      temperature: "Temperature",
      humidity: "Humidity",
      condition: "Partly Cloudy",
      recommendation: "Good conditions for crop monitoring",
      location: "Your Location"
    },
    telugu: {
      weather: "వాతావరణ వార్తలు",
      temperature: "ఉష్ణోగ్రత",
      humidity: "తేమ",
      condition: "పాక్షిక మేఘావృతం",
      recommendation: "పంట పర్యవేక్షణకు మంచి పరిస్థితులు",
      location: "మీ ప్రాంతం"
    }
  };

  const t = translations[language];

  // Mock weather data - in a real app, you'd fetch this from a weather API
  const weatherData = {
    temperature: 28,
    humidity: 65,
    condition: "partly_cloudy",
    recommendation: t.recommendation
  };

  const getWeatherIcon = (condition) => {
    switch (condition) {
      case 'sunny': return Sun;
      case 'cloudy': return Cloud;
      case 'rainy': return CloudRain;
      default: return Cloud;
    }
  };

  const WeatherIcon = getWeatherIcon(weatherData.condition);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
    >
      <Card className="farmer-card gradient-bg text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16" />
        
        <CardHeader className="pb-4 relative z-10">
          <CardTitle className="flex items-center gap-2">
            <WeatherIcon className="w-5 h-5" />
            {t.weather}
          </CardTitle>
          <p className="text-green-100 text-sm">{t.location}</p>
        </CardHeader>
        
        <CardContent className="relative z-10">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Thermometer className="w-6 h-6" />
                <span className="text-2xl font-bold">{weatherData.temperature}°C</span>
              </div>
              <Badge className="bg-white/20 text-white border-white/30">
                {t.condition}
              </Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-green-100 text-sm">{t.humidity}:</span>
              <span className="font-medium">{weatherData.humidity}%</span>
            </div>
            
            <div className="p-3 bg-white/10 rounded-xl">
              <p className="text-sm text-green-100">{weatherData.recommendation}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}