import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Droplets, Sun, Bug } from "lucide-react";
import { motion } from "framer-motion";

export default function HealthTips({ language }) {
  const translations = {
    english: {
      healthTips: "Crop Health Tips",
      tips: [
        {
          icon: Droplets,
          title: "Proper Watering",
          description: "Water crops early morning or late evening to prevent disease",
          category: "Water Management"
        },
        {
          icon: Sun,
          title: "Sunlight Exposure",
          description: "Ensure crops get 6-8 hours of direct sunlight daily",
          category: "Light Management"
        },
        {
          icon: Bug,
          title: "Pest Prevention",
          description: "Regular inspection helps catch problems early",
          category: "Pest Control"
        }
      ]
    },
    telugu: {
      healthTips: "పంట ఆరోగ్య చిట్కాలు",
      tips: [
        {
          icon: Droplets,
          title: "సరైన నీరు పట్టడం",
          description: "వ్యాధులను నివారించడానికి ఉదయం లేదా సాయంత్రం పంటలకు నీరు పట్టండి",
          category: "నీటి నిర్వహణ"
        },
        {
          icon: Sun,
          title: "సూర్యకాంతి బహిర్గతం",
          description: "పంటలకు రోజుకు 6-8 గంటల ప్రత్యక్ష సూర్యకాంతి అవసరం",
          category: "కాంతి నిర్వహణ"
        },
        {
          icon: Bug,
          title: "చీడపీడల నివారణ",
          description: "క్రమం తప్పకుండా తనిఖీ చేయడం సమస్యలను ముందుగా గుర్తించడంలో సహాయపడుతుంది",
          category: "చీడపీడల నియంత్రణ"
        }
      ]
    }
  };

  const t = translations[language];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
    >
      <Card className="farmer-card">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Lightbulb className="w-5 h-5" />
            {t.healthTips}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {t.tips.map((tip, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="p-4 border rounded-xl hover:bg-green-50 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <tip.icon className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{tip.description}</p>
                    <Badge variant="outline" className="text-xs">
                      {tip.category}
                    </Badge>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}