import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { AlertTriangle, CheckCircle, Clock, Leaf } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

export default function RecentScans({ analyses, isLoading, language }) {
  const translations = {
    english: {
      recentScans: "Recent Scans",
      noScans: "No scans yet",
      noScansDesc: "Take your first crop photo to get started",
      healthy: "Healthy",
      diseased: "Disease Detected"
    },
    telugu: {
      recentScans: "ఇటీవలి స్కాన్‌లు",
      noScans: "ఇంకా స్కాన్‌లు లేవు",
      noScansDesc: "ప్రారంభించడానికి మీ మొదటి పంట ఫోటో తీయండి",
      healthy: "ఆరోగ్యంగా",
      diseased: "వ్యాధి గుర్తించబడింది"
    }
  };

  const t = translations[language];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'low': return 'bg-yellow-100 text-yellow-800';
      case 'moderate': return 'bg-orange-100 text-orange-800';
      case 'high': return 'bg-red-100 text-red-800';
      case 'critical': return 'bg-red-200 text-red-900';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <Card className="farmer-card">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Clock className="w-5 h-5" />
            {t.recentScans}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="flex items-center gap-4 p-4 border rounded-xl">
                  <Skeleton className="w-16 h-16 rounded-lg" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
              ))}
            </div>
          ) : analyses.length === 0 ? (
            <div className="text-center py-12">
              <Leaf className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">{t.noScans}</h3>
              <p className="text-gray-500">{t.noScansDesc}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {analyses.slice(0, 5).map((analysis, index) => (
                <motion.div
                  key={analysis.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 p-4 border rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="relative">
                    <img
                      src={analysis.image_url}
                      alt="Crop scan"
                      className="w-16 h-16 object-cover rounded-lg border-2 border-gray-200"
                    />
                    <div className={`absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center ${
                      analysis.disease_detected && analysis.disease_severity !== 'low'
                        ? 'bg-red-500'
                        : 'bg-green-500'
                    }`}>
                      {analysis.disease_detected && analysis.disease_severity !== 'low' ? (
                        <AlertTriangle className="w-3 h-3 text-white" />
                      ) : (
                        <CheckCircle className="w-3 h-3 text-white" />
                      )}
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 capitalize">
                      {analysis.crop_type || 'Unknown Crop'}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      {analysis.disease_detected || t.healthy}
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(analysis.created_date), "MMM d, HH:mm")}
                    </p>
                  </div>
                  
                  <Badge className={getSeverityColor(analysis.disease_severity)}>
                    {analysis.disease_detected && analysis.disease_severity !== 'low' 
                      ? t.diseased 
                      : t.healthy
                    }
                  </Badge>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}