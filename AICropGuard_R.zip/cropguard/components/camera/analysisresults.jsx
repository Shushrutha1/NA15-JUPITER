
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  AlertTriangle, 
  Camera, 
  Shield, 
  Droplets,
  Clock,
  AlertCircle,
  Leaf
} from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import ReadAloudButton from "../common/ReadAloudButton";

export default function AnalysisResults({ analysis, onNewScan, language, voiceEnabled }) {
  const translations = {
    english: {
      analysisResults: "Analysis Results",
      cropHealth: "Crop Health Status",
      confidence: "Confidence",
      symptoms: "Observed Symptoms",
      diseaseDetails: "Disease Details",
      treatment: "Treatment Recommendations",
      prevention: "Prevention Tips",
      newScan: "New Scan",
      healthy: "Healthy",
      diseased: "Disease Detected",
      noSymptoms: "No significant symptoms observed",
      noPrevention: "Continue regular crop monitoring",
      scanAnother: "Scan Another Crop",
      possibleCauses: "Possible Causes",
      activeIngredient: "Active Ingredient",
      application: "Application",
      dosage: "Dosage",
      frequency: "Frequency",
      safetyInstructions: "Safety Instructions",
      noTreatment: "No specific treatment recommended.",
      greatNews: "Great news!",
      healthyCropMessage: "Your crop appears to be healthy with no significant disease detected. Continue with regular monitoring and care."
    },
    telugu: {
      analysisResults: "విశ్లేషణ ఫలితాలు",
      cropHealth: "పంట ఆరోగ్య స్థితి",
      confidence: "విశ్వాసం",
      symptoms: "గమనించిన లక్షణాలు",
      diseaseDetails: "వ్యాధి వివరాలు",
      treatment: "చికిత్స సిఫార్సులు",
      prevention: "నివారణ చిట్కాలు",
      newScan: "కొత్త స్కాన్",
      healthy: "ఆరోగ్యకరం",
      diseased: "వ్యాధి గుర్తించబడింది",
      noSymptoms: "ముఖ్యమైన లక్షణాలు కనిపించలేదు",
      noPrevention: "క్రమం తప్పకుండా పంట పర్యవేక్షణ కొనసాగించండి",
      scanAnother: "మరొక పంటను స్కాన్ చేయండి",
      possibleCauses: "సంభావ్య కారణాలు",
      activeIngredient: "క్రియాశీల పదార్ధం",
      application: "అప్లికేషన్",
      dosage: "మోతాదు",
      frequency: "ఆవర్తనం",
      safetyInstructions: "భద్రతా సూచనలు",
      noTreatment: "ప్రత్యేక చికిత్స సిఫార్సు చేయబడలేదు.",
      greatNews: "శుభవార్త!",
      healthyCropMessage: "మీ పంట ఆరోగ్యంగా ఉంది, ముఖ్యమైన వ్యాధి ఏదీ కనుగొనబడలేదు. సాధారణ పర్యవేక్షణ మరియు సంరక్షణను కొనసాగించండి."
    }
  };

  const t = translations[language];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'low': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'moderate': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'high': return 'bg-red-100 text-red-800 border-red-300';
      case 'critical': return 'bg-red-200 text-red-900 border-red-400';
      default: return 'bg-green-100 text-green-800 border-green-300';
    }
  };

  const getHealthIcon = () => {
    if (!analysis.disease_detected || analysis.disease_severity === 'low') {
      return <CheckCircle className="w-8 h-8 text-green-600" />;
    }
    return <AlertTriangle className="w-8 h-8 text-red-600" />;
  };

  const isHealthy = !analysis.disease_detected || analysis.disease_severity === 'low';

  // --- Functions to generate text for reading aloud ---
  const getDiseaseDetailsText = () => {
    let text = `${t.diseaseDetails}. `;
    text += `${t.diseased}: ${analysis.disease_detected}. `;
    text += `Description: ${analysis.analysis_details?.disease_description}. `;
    if (analysis.symptoms && analysis.symptoms.length > 0) {
      text += `${t.symptoms}: ${analysis.symptoms.join(', ')}. `;
    }
    if (analysis.analysis_details?.causes && analysis.analysis_details.causes.length > 0) {
      text += `${t.possibleCauses}: ${analysis.analysis_details.causes.join(', ')}.`;
    }
    return text;
  };

  const getTreatmentText = () => {
    let text = `${t.treatment}. `;
    if (analysis.pesticide_recommendations && analysis.pesticide_recommendations.length > 0) {
      analysis.pesticide_recommendations.forEach(p => {
        text += `Recommendation: ${p.name}. `;
        text += `${t.activeIngredient}: ${p.active_ingredient}. `;
        text += `${t.application}: ${p.application_method}. `;
        text += `${t.dosage}: ${p.dosage}. `;
        text += `${t.frequency}: ${p.frequency}. `;
        if (p.safety_instructions && p.safety_instructions.length > 0) {
          text += `${t.safetyInstructions}: ${p.safety_instructions.join('. ')}. `;
        }
      });
    } else {
      text += t.noTreatment;
    }
    return text;
  };

  const getPreventionText = () => {
    let text = `${t.prevention}. `;
    if (analysis.analysis_details?.prevention_tips && analysis.analysis_details.prevention_tips.length > 0) {
      text += analysis.analysis_details.prevention_tips.join('. ');
    } else {
      text += t.noPrevention;
    }
    return text;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header with Image and Basic Info */}
      <Card className="farmer-card">
        <CardContent className="p-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <img
                src={analysis.image_url}
                alt="Analyzed crop"
                className="w-full aspect-square object-cover rounded-xl border-2 border-gray-200"
              />
            </div>
            
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                {getHealthIcon()}
                <div>
                  <h2 className="text-2xl font-bold text-green-800">{t.cropHealth}</h2>
                  <p className="text-gray-600 capitalize">{analysis.crop_type} crop analysis</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Status</p>
                  <Badge className={`${getSeverityColor(analysis.disease_severity)} border`}>
                    {isHealthy ? t.healthy : t.diseased}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">{t.confidence}</p>
                  <Badge variant="outline">
                    {Math.round(analysis.confidence_score || 85)}%
                  </Badge>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Scan Date</p>
                <p className="font-medium">{format(new Date(analysis.created_date), "MMM d, yyyy HH:mm")}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Disease Details */}
      {analysis.disease_detected && analysis.disease_severity !== 'low' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="farmer-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-red-800">
                <AlertCircle className="w-5 h-5" />
                {t.diseaseDetails}
              </CardTitle>
              {voiceEnabled && (
                <ReadAloudButton
                  textToRead={getDiseaseDetailsText()}
                  language={language}
                />
              )}
            </CardHeader>
            <CardContent>
              <Alert className="mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>{analysis.disease_detected}</strong>
                  <br />
                  {analysis.analysis_details?.disease_description}
                </AlertDescription>
              </Alert>

              {analysis.symptoms && analysis.symptoms.length > 0 && (
                <div className="mb-4">
                  <h4 className="font-medium mb-2">{t.symptoms}</h4>
                  <ul className="space-y-1">
                    {analysis.symptoms.map((symptom, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-red-400 rounded-full" />
                        {symptom}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {analysis.analysis_details?.causes && (
                <div>
                  <h4 className="font-medium mb-2">{t.possibleCauses}</h4>
                  <ul className="space-y-1">
                    {analysis.analysis_details.causes.map((cause, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                        <div className="w-2 h-2 bg-orange-400 rounded-full" />
                        {cause}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Healthy Crop Message */}
      {isHealthy && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Alert className="border-green-300 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              <strong>{t.greatNews}</strong> {t.healthyCropMessage}
            </AlertDescription>
          </Alert>
        </motion.div>
      )}

      {/* Treatment Recommendations */}
      {analysis.pesticide_recommendations && analysis.pesticide_recommendations.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="farmer-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-green-800">
                <Shield className="w-5 h-5" />
                {t.treatment}
              </CardTitle>
              {voiceEnabled && (
                <ReadAloudButton
                  textToRead={getTreatmentText()}
                  language={language}
                />
              )}
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analysis.pesticide_recommendations.map((pesticide, index) => (
                  <div key={index} className="p-4 border rounded-xl bg-gradient-to-r from-blue-50 to-green-50">
                    <h4 className="font-bold text-green-800 mb-2">{pesticide.name}</h4>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p><strong>{t.activeIngredient}:</strong> {pesticide.active_ingredient}</p>
                        <p><strong>{t.application}:</strong> {pesticide.application_method}</p>
                      </div>
                      <div>
                        <p><strong>{t.dosage}:</strong> {pesticide.dosage}</p>
                        <p><strong>{t.frequency}:</strong> {pesticide.frequency}</p>
                      </div>
                    </div>
                    
                    {pesticide.safety_instructions && pesticide.safety_instructions.length > 0 && (
                      <div className="mt-3">
                        <h5 className="font-medium text-red-700 mb-1">{t.safetyInstructions}:</h5>
                        <ul className="text-xs space-y-1">
                          {pesticide.safety_instructions.map((instruction, idx) => (
                            <li key={idx} className="flex items-center gap-2">
                              <div className="w-1 h-1 bg-red-400 rounded-full" />
                              {instruction}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Prevention Tips */}
      {analysis.analysis_details?.prevention_tips && analysis.analysis_details.prevention_tips.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="farmer-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-green-800">
                <Leaf className="w-5 h-5" />
                {t.prevention}
              </CardTitle>
              {voiceEnabled && (
                <ReadAloudButton
                  textToRead={getPreventionText()}
                  language={language}
                />
              )}
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {analysis.analysis_details.prevention_tips.map((tip, index) => (
                  <li key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                    <div className="w-6 h-6 bg-green-200 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <div className="w-2 h-2 bg-green-600 rounded-full" />
                    </div>
                    <span className="text-sm text-gray-700">{tip}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Action Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="text-center"
      >
        <Button
          onClick={onNewScan}
          size="lg"
          className="bg-green-600 hover:bg-green-700 px-8"
        >
          <Camera className="w-5 h-5 mr-2" />
          {t.scanAnother}
        </Button>
      </motion.div>
    </motion.div>
  );
}
