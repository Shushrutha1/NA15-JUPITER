import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Upload, Smartphone, Image } from "lucide-react";
import { motion } from "framer-motion";

export default function CameraInterface({ onImageCapture, onFileUpload, fileInputRef, language }) {
  const translations = {
    english: {
      capturePhoto: "Capture Photo",
      captureDesc: "Use your camera to take a picture",
      uploadPhoto: "Upload Photo",
      uploadDesc: "Select an image from your device",
      supportedFormats: "Supported: PNG, JPG, JPEG"
    },
    telugu: {
      capturePhoto: "ఫోటో తీయండి",
      captureDesc: "మీ కెమెరాను ఉపయోగించి ఫోటో తీయండి",
      uploadPhoto: "ఫోటో అప్‌లోడ్ చేయండి",
      uploadDesc: "మీ పరికరం నుండి చిత్రాన్ని ఎంచుకోండి",
      supportedFormats: "మద్దతు: PNG, JPG, JPEG"
    }
  };

  const t = translations[language];
  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  const handleCameraCapture = () => {
    if (isMobile) {
      // On mobile, trigger file input with camera
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.capture = 'environment';
      input.onchange = (e) => {
        const file = e.target.files[0];
        if (file) onImageCapture(file);
      };
      input.click();
    } else {
      // On desktop, trigger regular file input
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      {/* Camera Capture */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="farmer-card h-full cursor-pointer group" onClick={handleCameraCapture}>
          <CardContent className="p-8 text-center">
            <div className="w-24 h-24 mx-auto mb-6 bg-green-100 rounded-full flex items-center justify-center group-hover:bg-green-200 transition-colors">
              {isMobile ? (
                <Smartphone className="w-12 h-12 text-green-600" />
              ) : (
                <Camera className="w-12 h-12 text-green-600" />
              )}
            </div>
            <h3 className="text-xl font-bold text-green-800 mb-3">{t.capturePhoto}</h3>
            <p className="text-gray-600 mb-6">{t.captureDesc}</p>
            <Button className="w-full bg-green-600 hover:bg-green-700">
              {isMobile ? (
                <>
                  <Smartphone className="w-5 h-5 mr-2" />
                  Open Camera
                </>
              ) : (
                <>
                  <Camera className="w-5 h-5 mr-2" />
                  Start Capture
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* File Upload */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="farmer-card h-full cursor-pointer group" onClick={() => fileInputRef.current?.click()}>
          <CardContent className="p-8 text-center">
            <div className="w-24 h-24 mx-auto mb-6 bg-blue-100 rounded-full flex items-center justify-center group-hover:bg-blue-200 transition-colors">
              <Upload className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-green-800 mb-3">{t.uploadPhoto}</h3>
            <p className="text-gray-600 mb-6">{t.uploadDesc}</p>
            <Button variant="outline" className="w-full border-blue-300 text-blue-600 hover:bg-blue-50">
              <Image className="w-5 h-5 mr-2" />
              Select Image
            </Button>
            <p className="text-xs text-gray-500 mt-4">{t.supportedFormats}</p>
          </CardContent>
        </Card>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={onFileUpload}
          className="hidden"
        />
      </motion.div>
    </div>
  );
}