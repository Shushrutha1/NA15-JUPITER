import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { RotateCcw, Scan } from "lucide-react";
import { motion } from "framer-motion";

export default function ImagePreview({ 
  image, 
  cropType, 
  setCropType, 
  cropTypes, 
  onAnalyze, 
  onRetake,
  language 
}) {
  const translations = {
    english: {
      imagePreview: "Image Preview",
      cropType: "Select Crop Type",
      selectCrop: "Choose your crop type",
      retakePhoto: "Retake Photo",
      analyzeNow: "Analyze Now",
      pleasSelect: "Please select crop type to continue"
    },
    telugu: {
      imagePreview: "చిత్ర ప్రివ్యూ",
      cropType: "పంట రకాన్ని ఎంచుకోండి",
      selectCrop: "మీ పంట రకాన్ని ఎంచుకోండి",
      retakePhoto: "మళ్లీ ఫోటో తీయండి",
      analyzeNow: "ఇప్పుడే విశ్లేషించండి",
      pleasSelect: "కొనసాగించడానికి దయచేసి పంట రకాన్ని ఎంచుకోండి"
    }
  };

  const t = translations[language];

  const formatCropName = (crop) => {
    return crop.charAt(0).toUpperCase() + crop.slice(1).replace(/_/g, ' ');
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-6"
    >
      {/* Image Preview */}
      <Card className="farmer-card">
        <CardHeader>
          <CardTitle className="text-green-800">{t.imagePreview}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="aspect-video bg-gray-100 rounded-xl overflow-hidden mb-4">
            <img
              src={URL.createObjectURL(image)}
              alt="Crop preview"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="cropType" className="text-base font-medium mb-2 block">
                {t.cropType}
              </Label>
              <Select value={cropType} onValueChange={setCropType}>
                <SelectTrigger>
                  <SelectValue placeholder={t.selectCrop} />
                </SelectTrigger>
                <SelectContent>
                  {cropTypes.map((crop) => (
                    <SelectItem key={crop} value={crop}>
                      {formatCropName(crop)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end gap-3">
              <Button
                variant="outline"
                onClick={onRetake}
                className="flex-1"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                {t.retakePhoto}
              </Button>
              
              <Button
                onClick={onAnalyze}
                disabled={!cropType}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <Scan className="w-4 h-4 mr-2" />
                {t.analyzeNow}
              </Button>
            </div>
          </div>
          
          {!cropType && (
            <p className="text-amber-600 text-sm mt-2 text-center">
              {t.pleasSelect}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}